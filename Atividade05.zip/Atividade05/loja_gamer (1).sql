-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02/09/2023 às 02:12
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `loja_gamer`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `ClienteID` int(11) NOT NULL,
  `Nome` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `DataNascimento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`ClienteID`, `Nome`, `Email`, `DataNascimento`) VALUES
(1, 'Mateus', 'mateus@gmail.com', '2008-05-10'),
(2, 'Carlos', 'carlos@gmail.com', '2010-12-12'),
(3, 'Maria', 'maria@gmail.com', '2009-06-25'),
(4, 'Brian', 'brian@gmail.com', '2008-05-10'),
(5, 'Julia', 'Julia@gmail.com', '0200-12-09');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itenspedido`
--

CREATE TABLE `itenspedido` (
  `ItemID` int(11) NOT NULL,
  `PedidoID` int(11) DEFAULT NULL,
  `ProdutoID` int(11) DEFAULT NULL,
  `Quantidade` int(11) DEFAULT NULL,
  `PrecoUnitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itenspedido`
--

INSERT INTO `itenspedido` (`ItemID`, `PedidoID`, `ProdutoID`, `Quantidade`, `PrecoUnitario`) VALUES
(1, 1, 1, 1, 70.00),
(2, 2, 2, 1, 200.00),
(3, 3, 3, 1, 400.00),
(4, 4, 4, 1, 600.00),
(5, 5, 5, 1, 316.00);

--
-- Acionadores `itenspedido`
--
DELIMITER $$
CREATE TRIGGER `AtualizarEstoqueAposVenda` AFTER INSERT ON `itenspedido` FOR EACH ROW BEGIN
    DECLARE produtoEstoque INT;
    DECLARE vendaQuantidade INT;
    
    -- Obtém o estoque atual do produto
    SELECT Estoque INTO produtoEstoque FROM Produtos WHERE ProdutoID = NEW.ProdutoID;
    
    -- Obtém a quantidade vendida no novo item de pedido
    SET vendaQuantidade = NEW.Quantidade;
    
    -- Calcula o novo estoque após a venda
    SET produtoEstoque = produtoEstoque - vendaQuantidade;
    
    -- Atualiza o estoque do produto
    UPDATE Produtos SET Estoque = produtoEstoque WHERE ProdutoID = NEW.ProdutoID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `PedidoID` int(11) NOT NULL,
  `ClienteID` int(11) DEFAULT NULL,
  `DataPedido` date DEFAULT NULL,
  `TotalPedido` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`PedidoID`, `ClienteID`, `DataPedido`, `TotalPedido`) VALUES
(1, 1, '2018-05-10', 70.00),
(2, 2, '2020-10-08', 200.00),
(3, 3, '2022-11-09', 400.00),
(4, 4, '2019-08-05', 600.00),
(5, 5, '2022-11-09', 316.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `ProdutoID` int(11) NOT NULL,
  `Nome` varchar(255) DEFAULT NULL,
  `Preco` decimal(10,2) DEFAULT NULL,
  `Estoque` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`ProdutoID`, `Nome`, `Preco`, `Estoque`) VALUES
(1, 'Teclado Gamer', 70.00, 47),
(2, 'Fone EDX PRO', 200.00, 49),
(3, 'Razer Viper Mini', 400.00, 49),
(4, 'Logitech G PRO Superlight s', 600.00, 49),
(5, 'Redragon K630 Dragonborne', 316.00, 49);

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `valortotalgastoporcliente`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `valortotalgastoporcliente` (
`ClienteID` int(11)
,`NomeCliente` varchar(255)
,`TotalGasto` decimal(42,2)
);

-- --------------------------------------------------------

--
-- Estrutura para view `valortotalgastoporcliente`
--
DROP TABLE IF EXISTS `valortotalgastoporcliente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `valortotalgastoporcliente`  AS SELECT `c`.`ClienteID` AS `ClienteID`, `c`.`Nome` AS `NomeCliente`, sum(`ip`.`Quantidade` * `ip`.`PrecoUnitario`) AS `TotalGasto` FROM ((`clientes` `c` left join `pedidos` `p` on(`c`.`ClienteID` = `p`.`ClienteID`)) left join `itenspedido` `ip` on(`p`.`PedidoID` = `ip`.`PedidoID`)) GROUP BY `c`.`ClienteID`, `c`.`Nome` ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`ClienteID`);

--
-- Índices de tabela `itenspedido`
--
ALTER TABLE `itenspedido`
  ADD PRIMARY KEY (`ItemID`),
  ADD KEY `PedidoID` (`PedidoID`),
  ADD KEY `ProdutoID` (`ProdutoID`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`PedidoID`),
  ADD KEY `ClienteID` (`ClienteID`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`ProdutoID`);

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `itenspedido`
--
ALTER TABLE `itenspedido`
  ADD CONSTRAINT `itenspedido_ibfk_1` FOREIGN KEY (`PedidoID`) REFERENCES `pedidos` (`PedidoID`),
  ADD CONSTRAINT `itenspedido_ibfk_2` FOREIGN KEY (`ProdutoID`) REFERENCES `produtos` (`ProdutoID`);

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`ClienteID`) REFERENCES `clientes` (`ClienteID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
